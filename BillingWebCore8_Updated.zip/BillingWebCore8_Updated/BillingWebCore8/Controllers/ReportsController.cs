using BillingWebCore8.Data;using BillingWebCore8.Models;using Microsoft.AspNetCore.Authorization;using Microsoft.AspNetCore.Mvc;using Microsoft.Data.SqlClient;
namespace BillingWebCore8.Controllers;[Authorize]public class ReportsController(SqlDb db):Controller{
 public IActionResult Index()=>View(new ReportVm());
 [HttpPost]public async Task<IActionResult> Run(ReportVm m){try{m.Rows=m.Report switch{
 "BillCharges"=>await db.QueryAsync("select * from billcharges order by mainac,accountno"),
 "StationaryDateWise"=>await db.QueryAsync("select * from consumedstationary where (@d is null or processdate=@d) order by citycode,bank,branch",new SqlParameter("@d",(object?)m.Date?.Date??DBNull.Value)),
 "StationaryTotal"=>await db.QueryAsync("select citycode,mainac,accountno,sum(itemused) itemused from consumedstationary group by citycode,mainac,accountno order by citycode,mainac,accountno"),
 "LateDaily"=>await db.QueryAsync("select * from latecomingclg where processdate=@d order by citycode,bank,branch",new SqlParameter("@d",m.Date?.Date??DateTime.Today)),
 "LateMonthly"=>await db.QueryAsync("select * from latecomingclg where month(processdate)=@m and year(processdate)=@y order by processdate,citycode,bank,branch",new SqlParameter("@m",m.Month??DateTime.Today.Month),new SqlParameter("@y",m.Year??DateTime.Today.Year)),
 "MissingBranches"=>await db.QueryAsync("select cityname,spb_memo_from from city order by cityname"),
 "ClearingCheck"=>await db.ProcAsync("CHK_clgdata",new SqlParameter("@mon",m.Month??DateTime.Today.Month),new SqlParameter("@yr",m.Year??DateTime.Today.Year)),
 "PreBundleCover"=>await db.QueryAsync("select * from prebundlecov where month(processdate)=@m and year(processdate)=@y order by processdate,bank,branch",new SqlParameter("@m",m.Month??DateTime.Today.Month),new SqlParameter("@y",m.Year??DateTime.Today.Year)),
 _=>[]};}catch(Exception ex){m.Message=ex.Message;}return View("Index",m);}
}
