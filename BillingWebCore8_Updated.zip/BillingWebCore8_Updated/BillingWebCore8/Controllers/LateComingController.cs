using BillingWebCore8.Data;
using BillingWebCore8.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace BillingWebCore8.Controllers;

[Authorize]
public class LateComingController(SqlDb db) : Controller
{
    public async Task<IActionResult> Index()
    {
        var vm = new LateComingPageVm
        {
            Form = new LateComingVm(),
            Cities = await db.QueryAsync("select citycode,cityname from city order by cityname"),
            Banks = await db.QueryAsync("select bank_code,bank_name from bank order by bank_code"),
            ProcessDates = await db.QueryAsync("select distinct cast(start_date as date) processdate from DBCLEARING..startofday order by processdate desc"),
            Rows = await db.QueryAsync("select top 300 * from latecomingclg order by processdate desc,citycode,bank,branch"),
            Message = TempData["Msg"] as string
        };
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(LateComingVm m)
    {
        if (!ModelState.IsValid)
        {
            TempData["Msg"] = "Invalid Process Date, Bank, Branch or Quantity.";
            return RedirectToAction(nameof(Index));
        }

        var dateExists = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from DBCLEARING..startofday where cast(start_date as date)=@d",
            new SqlParameter("@d", m.ProcessDate.Date)) ?? 0) > 0;
        if (!dateExists)
        {
            TempData["Msg"] = "Invalid Process Date.";
            return RedirectToAction(nameof(Index));
        }

        var bank = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from bank where bank_code=@b",
            new SqlParameter("@b", m.BankCode)) ?? 0);
        if (bank == 0)
        {
            TempData["Msg"] = "Invalid Bank.";
            return RedirectToAction(nameof(Index));
        }

        var branch = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from branch where citycode=@c and bank_code=@b and branch_code=@br",
            new SqlParameter("@c", m.CityCode),
            new SqlParameter("@b", m.BankCode),
            new SqlParameter("@br", m.BranchCode)) ?? 0);
        if (branch == 0)
        {
            TempData["Msg"] = "This Branch is not associated with selected City/Bank.";
            return RedirectToAction(nameof(Index));
        }

        var dupe = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from latecomingclg where citycode=@c and processdate=@d and bank=@b and branch=@br",
            new SqlParameter("@c", m.CityCode),
            new SqlParameter("@d", m.ProcessDate.Date),
            new SqlParameter("@b", m.BankCode),
            new SqlParameter("@br", m.BranchCode)) ?? 0);
        if (dupe > 0)
        {
            TempData["Msg"] = "Record already exists for this Process Date, Bank and Branch.";
            return RedirectToAction(nameof(Index));
        }

        var rec = Convert.ToInt32(await db.ScalarAsync("select isnull(max(recno),0)+1 from latecomingclg") ?? 1);
        await db.ExecuteAsync(
            "insert into latecomingclg(processdate,mainac,accountno,bank,branch,itemused,recno,timet,citycode) values(@d,18,18022,@b,@br,@q,@rec,@tm,@c)",
            new SqlParameter("@d", m.ProcessDate.Date),
            new SqlParameter("@b", m.BankCode),
            new SqlParameter("@br", m.BranchCode),
            new SqlParameter("@q", m.Quantity),
            new SqlParameter("@rec", rec),
            new SqlParameter("@tm", m.TimeText ?? ""),
            new SqlParameter("@c", m.CityCode));

        TempData["Msg"] = "Late-coming record inserted.";
        return RedirectToAction(nameof(Index));
    }
}
