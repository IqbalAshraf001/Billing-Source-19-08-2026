# BillingWebCore10 - VB.NET Billing Migration

ASP.NET Core 10 MVC conversion of the legacy VB.NET Billing application.

## Runtime
- Target framework: `net10.0`
- SQL provider: `Microsoft.Data.SqlClient 7.0.2`
- Directory Services package: `System.DirectoryServices.AccountManagement 10.0.9`
- Authentication defaults to `DatabaseOnly` in `appsettings.json`; existing SQL Login-table locking/session behavior is retained.

## Business-logic corrections in this build
### Stationery and Images Hard Copies
The web screen now follows the legacy `FrmStationary` behavior more closely:
- Process dates come from `DBCLEARING..startofday`.
- Banks come from the Billing `bank` table.
- Account code is validated against `billcharges` by City + Main Account + Account No.
- Branch is validated against City + Bank + Branch.
- Existing records can be opened with **Edit** and the stored quantity is converted back to the operator-entry quantity.
- Legacy quantity multipliers are applied before saving `consumedstationary.itemused`:
  - 19001 => Qty x 100
  - 19009 => Qty x 100
  - 19008 => Qty x 75
  - 19002 => Qty x 75
  - 19021 => Qty x 75
  - 19019 => Qty x 75
  - 19020 => Qty x 75
  - 19004 => Qty x 50
  - all other account codes => Qty x 1
- Insert, Update and Delete remain parameterized SQL.

### Late-coming entry
- Process date is selected from `DBCLEARING..startofday`.
- Bank and City are selected from master data.
- Bank, City/Bank/Branch, duplicate ProcessDate+Bank+Branch and `recno=max+1` checks are retained.
- Insert explicitly includes `citycode`.

### Load Data
The operation list now includes the full legacy `frmloaddata` stored-procedure set found in the source dependency inventory, plus bundle/jotting utilities.

## Configuration
Edit `appsettings.json` and set `ConnectionStrings:BillingDb`.

Then restore/build using a machine with the .NET 10 SDK:

    dotnet restore
    dotnet build
    dotnet run

## Crystal Reports
The original `.rpt` files remain under `LegacyReports`. Legacy WinForms Crystal Report viewers cannot be hosted directly by ASP.NET Core; browser reporting remains query/print based until an ASP.NET Core-compatible report renderer is selected.

## UAT note
Use the legacy VB.NET forms as the acceptance reference. This build specifically corrects the confirmed Stationary quantity rules and the related master-data validations, and expands the legacy data-load procedure coverage.
