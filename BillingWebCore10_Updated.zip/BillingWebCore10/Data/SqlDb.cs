using Microsoft.Data.SqlClient;
using System.Data;
namespace BillingWebCore10.Data;
public sealed class SqlDb(IConfiguration cfg) {
  readonly string _cs=cfg.GetConnectionString("BillingDb") ?? throw new InvalidOperationException("BillingDb connection string missing.");
  public SqlConnection Open(){var c=new SqlConnection(_cs);c.Open();return c;}
  public async Task<List<Dictionary<string,object?>>> QueryAsync(string sql, params SqlParameter[] ps){
    using var c=Open(); using var cmd=new SqlCommand(sql,c); if(ps.Length>0)cmd.Parameters.AddRange(ps); using var r=await cmd.ExecuteReaderAsync();
    var rows=new List<Dictionary<string,object?>>(); while(await r.ReadAsync()){var d=new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase);for(int i=0;i<r.FieldCount;i++)d[r.GetName(i)]=r.IsDBNull(i)?null:r.GetValue(i);rows.Add(d);} return rows;
  }
  public async Task<int> ExecuteAsync(string sql, params SqlParameter[] ps){using var c=Open();using var cmd=new SqlCommand(sql,c);if(ps.Length>0)cmd.Parameters.AddRange(ps);return await cmd.ExecuteNonQueryAsync();}
  public async Task<object?> ScalarAsync(string sql, params SqlParameter[] ps){using var c=Open();using var cmd=new SqlCommand(sql,c);if(ps.Length>0)cmd.Parameters.AddRange(ps);return await cmd.ExecuteScalarAsync();}
  public async Task<List<Dictionary<string,object?>>> ProcAsync(string name, params SqlParameter[] ps){using var c=Open();using var cmd=new SqlCommand(name,c){CommandType=CommandType.StoredProcedure,CommandTimeout=0};if(ps.Length>0)cmd.Parameters.AddRange(ps);using var r=await cmd.ExecuteReaderAsync();var rows=new List<Dictionary<string,object?>>();while(await r.ReadAsync()){var d=new Dictionary<string,object?>(StringComparer.OrdinalIgnoreCase);for(int i=0;i<r.FieldCount;i++)d[r.GetName(i)]=r.IsDBNull(i)?null:r.GetValue(i);rows.Add(d);}return rows;}
}
