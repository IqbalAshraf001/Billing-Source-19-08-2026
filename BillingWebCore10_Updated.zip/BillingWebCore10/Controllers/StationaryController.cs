using BillingWebCore10.Data;
using BillingWebCore10.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace BillingWebCore10.Controllers;

[Authorize]
public class StationaryController(SqlDb db) : Controller
{
    private static int QuantityFactor(int accountNo) => accountNo switch
    {
        19001 or 19009 => 100,
        19008 or 19002 or 19021 or 19019 or 19020 => 75,
        19004 => 50,
        _ => 1
    };

    public async Task<IActionResult> Index(
        int? cityCode,
        int? accountNo,
        int? bankCode,
        int? branchCode,
        DateTime? processDate,
        int? mainAc)
    {
        var form = new StationaryVm
        {
            CityCode = cityCode ?? 0,
            AccountNo = accountNo ?? 0,
            BankCode = bankCode ?? 0,
            BranchCode = branchCode ?? 0,
            ProcessDate = processDate?.Date ?? DateTime.Today,
            MainAc = mainAc ?? 19
        };

        var vm = await BuildPageAsync(form);
        vm.Message = TempData["Msg"] as string;

        if (cityCode.HasValue && accountNo.HasValue && bankCode.HasValue && branchCode.HasValue && processDate.HasValue)
        {
            var rows = await db.QueryAsync(
                "select top 1 processdate,mainac,accountno,bank,branch,itemused,citycode from consumedstationary where citycode=@c and accountno=@a and bank=@b and branch=@br and processdate=@d",
                new SqlParameter("@c", cityCode.Value),
                new SqlParameter("@a", accountNo.Value),
                new SqlParameter("@b", bankCode.Value),
                new SqlParameter("@br", branchCode.Value),
                new SqlParameter("@d", processDate.Value.Date));

            if (rows.Count > 0)
            {
                var row = rows[0];
                var storedQty = Convert.ToInt32(row["itemused"] ?? 0);
                var factor = QuantityFactor(accountNo.Value);
                vm.Form = new StationaryVm
                {
                    CityCode = Convert.ToInt32(row["citycode"] ?? cityCode.Value),
                    ProcessDate = Convert.ToDateTime(row["processdate"] ?? processDate.Value).Date,
                    MainAc = Convert.ToInt32(row["mainac"] ?? 19),
                    AccountNo = Convert.ToInt32(row["accountno"] ?? accountNo.Value),
                    BankCode = Convert.ToInt32(row["bank"] ?? bankCode.Value),
                    BranchCode = Convert.ToInt32(row["branch"] ?? branchCode.Value),
                    Quantity = factor == 1 ? storedQty : storedQty / factor
                };
                vm.IsEdit = true;
                await FillDescriptionsAsync(vm);
            }
        }

        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Save(StationaryVm m)
    {
        if (!ModelState.IsValid)
        {
            TempData["Msg"] = "Invalid Process Date, Account No, Branch or Quantity.";
            return RedirectToAction(nameof(Index));
        }

        var dateExists = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from DBCLEARING..startofday where cast(start_date as date)=@d",
            new SqlParameter("@d", m.ProcessDate.Date)) ?? 0) > 0;
        if (!dateExists)
        {
            TempData["Msg"] = "Invalid Process Date. Select a date available in DBCLEARING..startofday.";
            return RedirectToAction(nameof(Index));
        }

        var accountExists = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from billcharges where citycode=@c and mainac=@m and accountno=@a",
            new SqlParameter("@c", m.CityCode),
            new SqlParameter("@m", m.MainAc),
            new SqlParameter("@a", m.AccountNo)) ?? 0) > 0;
        if (!accountExists)
        {
            TempData["Msg"] = "Invalid Account No for selected City/Type.";
            return RedirectToAction(nameof(Index));
        }

        var bankExists = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from bank where bank_code=@b",
            new SqlParameter("@b", m.BankCode)) ?? 0) > 0;
        if (!bankExists)
        {
            TempData["Msg"] = "Invalid Bank.";
            return RedirectToAction(nameof(Index));
        }

        var branchExists = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from branch where citycode=@c and bank_code=@b and branch_code=@br",
            new SqlParameter("@c", m.CityCode),
            new SqlParameter("@b", m.BankCode),
            new SqlParameter("@br", m.BranchCode)) ?? 0) > 0;
        if (!branchExists)
        {
            TempData["Msg"] = "This Branch is not associated with the selected City/Bank.";
            return RedirectToAction(nameof(Index));
        }

        var storedQuantity = checked(m.Quantity * QuantityFactor(m.AccountNo));
        var exists = Convert.ToInt32(await db.ScalarAsync(
            "select count(*) from consumedstationary where citycode=@c and accountno=@a and bank=@b and branch=@br and processdate=@d",
            new SqlParameter("@c", m.CityCode),
            new SqlParameter("@a", m.AccountNo),
            new SqlParameter("@b", m.BankCode),
            new SqlParameter("@br", m.BranchCode),
            new SqlParameter("@d", m.ProcessDate.Date)) ?? 0) > 0;

        if (exists)
        {
            await db.ExecuteAsync(
                "update consumedstationary set mainac=@m,itemused=@q where citycode=@c and accountno=@a and bank=@b and branch=@br and processdate=@d",
                new SqlParameter("@m", m.MainAc),
                new SqlParameter("@q", storedQuantity),
                new SqlParameter("@c", m.CityCode),
                new SqlParameter("@a", m.AccountNo),
                new SqlParameter("@b", m.BankCode),
                new SqlParameter("@br", m.BranchCode),
                new SqlParameter("@d", m.ProcessDate.Date));
            TempData["Msg"] = $"Record updated. Entered Qty {m.Quantity}; stored ItemUsed {storedQuantity}.";
        }
        else
        {
            await db.ExecuteAsync(
                "insert into consumedstationary(processdate,mainac,accountno,bank,branch,itemused,citycode) values(@d,@m,@a,@b,@br,@q,@c)",
                new SqlParameter("@d", m.ProcessDate.Date),
                new SqlParameter("@m", m.MainAc),
                new SqlParameter("@a", m.AccountNo),
                new SqlParameter("@b", m.BankCode),
                new SqlParameter("@br", m.BranchCode),
                new SqlParameter("@q", storedQuantity),
                new SqlParameter("@c", m.CityCode));
            TempData["Msg"] = $"Record inserted. Entered Qty {m.Quantity}; stored ItemUsed {storedQuantity}.";
        }

        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(StationaryVm m)
    {
        await db.ExecuteAsync(
            "delete from consumedstationary where citycode=@c and accountno=@a and bank=@b and branch=@br and processdate=@d",
            new SqlParameter("@c", m.CityCode),
            new SqlParameter("@a", m.AccountNo),
            new SqlParameter("@b", m.BankCode),
            new SqlParameter("@br", m.BranchCode),
            new SqlParameter("@d", m.ProcessDate.Date));
        TempData["Msg"] = "Record has been deleted.";
        return RedirectToAction(nameof(Index));
    }

    private async Task<StationaryPageVm> BuildPageAsync(StationaryVm form)
    {
        return new StationaryPageVm
        {
            Form = form,
            Cities = await db.QueryAsync("select citycode,cityname from city order by cityname"),
            Banks = await db.QueryAsync("select bank_code,bank_name from bank order by bank_code"),
            ProcessDates = await db.QueryAsync("select distinct cast(start_date as date) processdate from DBCLEARING..startofday order by processdate desc"),
            Rows = await db.QueryAsync("select top 300 processdate,mainac,accountno,bank,branch,itemused,citycode from consumedstationary order by processdate desc,citycode,bank,branch,accountno")
        };
    }

    private async Task FillDescriptionsAsync(StationaryPageVm vm)
    {
        vm.AccountDescription = Convert.ToString(await db.ScalarAsync(
            "select top 1 acdesc from billcharges where citycode=@c and mainac=@m and accountno=@a",
            new SqlParameter("@c", vm.Form.CityCode),
            new SqlParameter("@m", vm.Form.MainAc),
            new SqlParameter("@a", vm.Form.AccountNo)));
        vm.BranchDescription = Convert.ToString(await db.ScalarAsync(
            "select top 1 branch_name from branch where citycode=@c and bank_code=@b and branch_code=@br",
            new SqlParameter("@c", vm.Form.CityCode),
            new SqlParameter("@b", vm.Form.BankCode),
            new SqlParameter("@br", vm.Form.BranchCode)));
    }
}
