using BillingWebCore10.Models;using BillingWebCore10.Services;using Microsoft.AspNetCore.Authentication;using Microsoft.AspNetCore.Authentication.Cookies;using Microsoft.AspNetCore.Mvc;using System.Security.Claims;
namespace BillingWebCore10.Controllers;
public class AccountController(AuthService auth):Controller{
 [HttpGet]public IActionResult Login()=>View(new LoginVm());
 [HttpPost,ValidateAntiForgeryToken]public async Task<IActionResult> Login(LoginVm m){if(!ModelState.IsValid)return View(m);var r=await auth.ValidateAsync(m.UserName,m.Password);if(!r.ok){m.Error=r.message;return View(m);}var claims=new[]{new Claim(ClaimTypes.Name,m.UserName.Trim()),new Claim("UserId",r.userId.ToString()),new Claim("RoleNo",r.role.ToString())};await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(new ClaimsIdentity(claims,CookieAuthenticationDefaults.AuthenticationScheme)));return RedirectToAction("Index","Home");}
 public async Task<IActionResult> Logout(){if(User.Identity?.Name is string u)await auth.LogoutAsync(u);await HttpContext.SignOutAsync();return RedirectToAction(nameof(Login));}
}
