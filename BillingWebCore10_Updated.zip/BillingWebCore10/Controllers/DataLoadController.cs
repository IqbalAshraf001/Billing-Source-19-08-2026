using BillingWebCore10.Data;
using BillingWebCore10.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace BillingWebCore10.Controllers;

[Authorize]
public class DataLoadController(SqlDb db) : Controller
{
    // Includes all procedures found in the legacy frmloaddata plus bundle/jotting utilities.
    private static readonly HashSet<string> Ops = new(StringComparer.OrdinalIgnoreCase)
    {
        "loadbundle", "loadjotting", "updatejotting", "checkdatatmp",
        "allclgbranchchk", "clg_nonstd", "clgnonstd_del",
        "clgpro_del", "clgpro_stat", "eleccbook", "eleccbookins",
        "icclgpro_del", "icclgpro_stat", "nonprocbook", "nonprocbookins",
        "procbook", "procbookins", "proclg", "proclgins",
        "prodolclg", "prodolclgins", "proicclg", "proicclghis",
        "proicclghis2", "proicclgins", "reportproclg", "reportproclgins",
        "smclgpro_del", "smclgpro_stat", "spproclg", "spproclgins", "updtspcial"
    };

    public IActionResult Index() => View(new LoadDataVm { Message = TempData["Msg"] as string });

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Run(LoadDataVm m)
    {
        if (!ModelState.IsValid)
        {
            m.Message = "Invalid month/year.";
            return View("Index", m);
        }
        if (!Ops.Contains(m.Operation))
        {
            m.Message = "Unknown operation.";
            return View("Index", m);
        }

        try
        {
            if (m.Operation.Equals("allclgbranchchk", StringComparison.OrdinalIgnoreCase))
            {
                m.Rows = await db.ProcAsync(m.Operation);
            }
            else
            {
                m.Rows = await db.ProcAsync(m.Operation,
                    new SqlParameter("@mon", m.Month),
                    new SqlParameter("@yr", m.Year));
            }
            m.Message = $"{m.Operation} executed successfully.";
        }
        catch (SqlException ex)
        {
            m.Message = $"{m.Operation}: {ex.Message}";
        }
        return View("Index", m);
    }
}
