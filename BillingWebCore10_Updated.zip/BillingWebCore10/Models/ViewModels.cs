using System.ComponentModel.DataAnnotations;
namespace BillingWebCore10.Models;

public class LoginVm
{
    [Required] public string UserName { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
    public string? Error { get; set; }
}

public class BankVm
{
    [Required, Range(1, int.MaxValue)] public int BankCode { get; set; }
    [Required] public string BankName { get; set; } = "";
}

public class BranchVm
{
    [Required, Range(1, int.MaxValue)] public int BankCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int BranchCode { get; set; }
    [Required] public string BranchName { get; set; } = "";
    public string Address { get; set; } = "";
    public int Zone { get; set; }
    public string Fax { get; set; } = "";
    public string Telephone { get; set; } = "";
    public string Email { get; set; } = "";
    public string Direct { get; set; } = "";
    public string Mobile { get; set; } = "";
    public string Manager { get; set; } = "";
    public string ManagerEmail { get; set; } = "";
    public string ManagerFax { get; set; } = "";
    [Required, Range(1, int.MaxValue)] public int CityCode { get; set; }
    public string Services { get; set; } = "";
}

public class StationaryVm
{
    [Required, Range(1, int.MaxValue)] public int CityCode { get; set; }
    [Required, DataType(DataType.Date)] public DateTime ProcessDate { get; set; } = DateTime.Today;
    [Required, Range(1, int.MaxValue)] public int AccountNo { get; set; }
    [Required, Range(1, int.MaxValue)] public int BankCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int BranchCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int Quantity { get; set; }
    [Required] public int MainAc { get; set; } = 19;
}

public class AdditionalServiceVm
{
    [Required, Range(1, int.MaxValue)] public int CityCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int AccountNo { get; set; }
    [Required, Range(1, int.MaxValue)] public int BankCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int BranchCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int WorkingDays { get; set; } = 22;
    [Required, Range(1, int.MaxValue)] public int Quantity { get; set; } = 1;
    [Required] public int Cycle { get; set; } = 2;
    [Range(typeof(decimal), "0", "999999999999")] public decimal Rate { get; set; }
    public string Description { get; set; } = "";
}

public class LateComingVm
{
    [Required, Range(1, int.MaxValue)] public int CityCode { get; set; }
    [Required, DataType(DataType.Date)] public DateTime ProcessDate { get; set; } = DateTime.Today;
    [Required, Range(1, int.MaxValue)] public int BankCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int BranchCode { get; set; }
    [Required, Range(1, int.MaxValue)] public int Quantity { get; set; }
    public string TimeText { get; set; } = "";
}

public class LoadDataVm
{
    [Range(1, 12)] public int Month { get; set; } = DateTime.Today.Month;
    [Range(2000, 2100)] public int Year { get; set; } = DateTime.Today.Year;
    public string Operation { get; set; } = "loadbundle";
    public string? Message { get; set; }
    public List<Dictionary<string, object?>> Rows { get; set; } = [];
}

public class ReportVm
{
    public string Report { get; set; } = "";
    public int? Month { get; set; }
    public int? Year { get; set; }
    public DateTime? Date { get; set; }
    public int? CityCode { get; set; }
    public string? Message { get; set; }
    public List<Dictionary<string, object?>> Rows { get; set; } = [];
}

public class StationaryPageVm
{
    public StationaryVm Form { get; set; } = new();
    public List<Dictionary<string, object?>> Cities { get; set; } = [];
    public List<Dictionary<string, object?>> Banks { get; set; } = [];
    public List<Dictionary<string, object?>> ProcessDates { get; set; } = [];
    public List<Dictionary<string, object?>> Rows { get; set; } = [];
    public string? AccountDescription { get; set; }
    public string? BranchDescription { get; set; }
    public string? Message { get; set; }
    public bool IsEdit { get; set; }
}

public class AdditionalServicePageVm
{
    public AdditionalServiceVm Form { get; set; } = new();
    public List<Dictionary<string, object?>> Cities { get; set; } = [];
    public List<Dictionary<string, object?>> Rows { get; set; } = [];
}

public class LateComingPageVm
{
    public LateComingVm Form { get; set; } = new();
    public List<Dictionary<string, object?>> Cities { get; set; } = [];
    public List<Dictionary<string, object?>> Banks { get; set; } = [];
    public List<Dictionary<string, object?>> ProcessDates { get; set; } = [];
    public List<Dictionary<string, object?>> Rows { get; set; } = [];
    public string? Message { get; set; }
}
