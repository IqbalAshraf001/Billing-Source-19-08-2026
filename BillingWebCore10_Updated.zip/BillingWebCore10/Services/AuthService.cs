using BillingWebCore10.Data;
using Microsoft.Data.SqlClient;
using System.DirectoryServices.AccountManagement;
namespace BillingWebCore10.Services;
public sealed class AuthService(SqlDb db,IConfiguration cfg){
 public async Task<(bool ok,string message,int userId,int role)> ValidateAsync(string user,string password){
   var rows=await db.QueryAsync("select top 1 * from Login where user_name=@u",new SqlParameter("@u",user.Trim()));
   if(rows.Count==0)return(false,"Domain UserID not registered in DB.",0,0);
   var row=rows[0]; if(Convert.ToInt32(row.GetValueOrDefault("online_status")??0)!=0)return(false,"UserID locked or already open at other PC.",0,0);
   var mode=cfg["Authentication:Mode"]??"DatabaseOnly";
   int role=Convert.ToInt32(row.GetValueOrDefault("user_Gmo")??0);
   if(mode.Equals("ActiveDirectory",StringComparison.OrdinalIgnoreCase)){
     if(!OperatingSystem.IsWindows())return(false,"Active Directory authentication requires Windows hosting.",0,0);
     var domain=cfg["Authentication:Domain"]??"nift.pk"; using var pc=new PrincipalContext(ContextType.Domain,domain);
     if(!pc.ValidateCredentials(user.Trim(),password))return(false,"Invalid domain user name or password.",0,0);
     var groups=new[]{("Branch Manager",1),("Supervisor",2),("Electronic Matching Operator",3),("Operation Officer",4),("Data Control officer",5),("Enquiry officer",6),("Account Officer",7)};
     using var up=UserPrincipal.FindByIdentity(pc,user.Trim()); if(up?.AccountExpirationDate!=null)return(false,"Domain UserID expired.",0,0);if(up?.IsAccountLockedOut()==true)return(false,"Domain UserID locked.",0,0);
     foreach(var (g,n) in groups){using var gp=GroupPrincipal.FindByIdentity(pc,g); if(gp!=null && up!=null && up.IsMemberOf(gp)){role=n;break;}}
   }
   int id=Convert.ToInt32(row["user_id"]); await db.ExecuteAsync("update Login set online_status=1,last_login=@d,ptime=@t,user_Gmo=case when @r=0 then isnull(user_Gmo,0) else @r end where user_id=@id",new SqlParameter("@d",DateTime.Today),new SqlParameter("@t",DateTime.Now.ToString("HH:mm:ss")),new SqlParameter("@r",role),new SqlParameter("@id",id));
   return(true,"OK",id,role);
 }
 public Task LogoutAsync(string user)=>db.ExecuteAsync("update Login set online_status=0 where user_name=@u",new SqlParameter("@u",user));
}
